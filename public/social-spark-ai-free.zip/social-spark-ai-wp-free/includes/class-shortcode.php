<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Social_Spark_AI_Shortcode {
    
    public function __construct() {
        add_shortcode( 'social_spark_ai', [ $this, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public function enqueue_assets() {
        // Only enqueue if the shortcode is present on the page (optimization)
        global $post;
        if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'social_spark_ai' ) ) {
            
            // We will load the Vite build files here
            $manifest_path = SOCIAL_SPARK_AI_PLUGIN_DIR . 'frontend/dist/.vite/manifest.json';
            
            if ( file_exists( $manifest_path ) ) {
                $manifest = json_decode( file_get_contents( $manifest_path ), true );
                
                $js_file = $manifest['src/main.tsx']['file'];
                $css_file = $manifest['src/main.tsx']['css'][0];

                wp_enqueue_script(
                    'social-spark-ai-app',
                    SOCIAL_SPARK_AI_PLUGIN_URL . 'frontend/dist/' . $js_file,
                    [],
                    SOCIAL_SPARK_AI_VERSION,
                    true
                );

                wp_enqueue_style(
                    'social-spark-ai-style',
                    SOCIAL_SPARK_AI_PLUGIN_URL . 'frontend/dist/' . $css_file,
                    [],
                    SOCIAL_SPARK_AI_VERSION
                );

                // Pass the REST API URL to React
                wp_localize_script( 'social-spark-ai-app', 'SocialSparkAIConfig', [
                    'apiUrl' => esc_url_raw( rest_url( 'social-spark/v1' ) ),
                    'nonce'  => wp_create_nonce( 'wp_rest' )
                ]);
            }
        }
    }

    public function render_shortcode() {
        return '<div id="social-spark-ai-root">Loading Social Spark AI...</div>';
    }
}
