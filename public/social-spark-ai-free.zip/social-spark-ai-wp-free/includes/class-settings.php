<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Social_Spark_AI_Settings {
    
    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_settings_page' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
    }

    public function add_settings_page() {
        add_options_page(
            'Social Spark AI Settings',
            'Social Spark AI',
            'manage_options',
            'social-spark-ai',
            [ $this, 'render_settings_page' ]
        );
    }

    public function register_settings() {
        register_setting( 'social_spark_ai_options_group', 'social_spark_ai_openai_key' );
        
        add_settings_section(
            'social_spark_ai_main_section',
            'API Configuration',
            null,
            'social-spark-ai'
        );

        add_settings_field(
            'social_spark_ai_openai_key',
            'OpenAI API Key',
            [ $this, 'render_openai_key_field' ],
            'social-spark-ai',
            'social_spark_ai_main_section'
        );
    }

    public function render_openai_key_field() {
        $key = get_option( 'social_spark_ai_openai_key', '' );
        echo '<input type="password" name="social_spark_ai_openai_key" value="' . esc_attr( $key ) . '" class="regular-text" placeholder="sk-..." />';
        echo '<p class="description">Enter your OpenAI API key to enable content generation.</p>';
    }

    public function render_settings_page() {
        ?>
        <div class="wrap" style="max-w-4xl;">
            <h1 style="margin-bottom: 20px;">Social Spark AI (FREE) Settings</h1>

            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 8px; color: white; margin-bottom: 30px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                <h2 style="color: white; font-size: 24px; margin-top: 0;">Unlock 30-Day Storytelling Content! 🚀</h2>
                <p style="font-size: 16px; margin-bottom: 20px;">You are using the Free version (Limited to short 50-word blurbs). Upgrade to PRO to unlock our proprietary 3-4 paragraph Narrative Storytelling Architecture that converts readers into buyers!</p>
                <a href="https://digital.pandian-ai.com" target="_blank" style="background: #fff; color: #764ba2; padding: 12px 24px; text-decoration: none; font-weight: bold; border-radius: 30px; display: inline-block; font-size: 16px; transition: transform 0.2s;">Upgrade to PRO Now — Only ₹999</a>
            </div>
            
            <div style="background: #fff; padding: 20px; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04); margin-bottom: 30px;">
                <form method="post" action="options.php">
                    <?php
                    settings_fields( 'social_spark_ai_options_group' );
                    do_settings_sections( 'social-spark-ai' );
                    submit_button('Save API Key');
                    ?>
                </form>
            </div>

            <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 300px; background: #f0f6fc; padding: 20px; border: 1px solid #c8e1ff; border-radius: 5px;">
                    <h2 style="margin-top: 0; color: #0366d6;">Step 1: Get Your API Key</h2>
                    <ol style="padding-left: 20px;">
                        <li>Go to <a href="https://platform.openai.com/signup" target="_blank">OpenAI's Platform</a> and create an account.</li>
                        <li>Navigate to <strong>API Keys</strong> on the left sidebar.</li>
                        <li>Click <strong>Create new secret key</strong> and copy it.</li>
                        <li>Paste it into the field above and click Save.</li>
                    </ol>
                </div>

                <div style="flex: 1; min-width: 300px; background: #f0f6fc; padding: 20px; border: 1px solid #c8e1ff; border-radius: 5px;">
                    <h2 style="margin-top: 0; color: #0366d6;">Step 2: Add $5 Credit</h2>
                    <ol style="padding-left: 20px;">
                        <li>To activate your API key, you must add credits.</li>
                        <li>Go to <strong>Settings -> Billing</strong> in OpenAI.</li>
                        <li>Add a payment method and top up a minimum of $5.</li>
                        <li><em>Note: Generating a 30-day campaign usually costs less than $0.10!</em></li>
                    </ol>
                </div>

                <div style="flex: 1; min-width: 300px; background: #fff8c5; padding: 20px; border: 1px solid #e1dfa4; border-radius: 5px;">
                    <h2 style="margin-top: 0; color: #b08800;">Step 3: Secure Your Data (Important)</h2>
                    <ol style="padding-left: 20px;">
                        <li>Ensure OpenAI never trains on your content.</li>
                        <li>Visit <a href="https://platform.openai.com/settings/organization/data-controls" target="_blank">OpenAI Data Controls</a>.</li>
                        <li>Click the <strong>Sharing</strong> tab at the top.</li>
                        <li>For all 3 sections on that page, select <strong>"Enabled for all projects"</strong>.</li>
                        <li>This gives you unlimited data privacy.</li>
                    </ol>
                </div>
            </div>

            <hr style="margin: 30px 0;">
            <h2>How to Display the Tool</h2>
            <p>Paste this shortcode anywhere on a Page or Post to display the Social Spark AI tool to your users:</p>
            <code style="font-size: 16px; padding: 10px; display: inline-block; background: #e2e4e7;">[social_spark_ai]</code>
        </div>
        <?php
    }
}
