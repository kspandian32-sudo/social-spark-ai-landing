<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Social_Spark_AI_API {
    
    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'social-spark/v1', '/generate', [
            'methods'  => 'POST',
            'callback' => [ $this, 'handle_generate' ],
            'permission_callback' => '__return_true', // Publicly accessible for now (protect via nonce later if needed)
        ]);

        register_rest_route( 'social-spark/v1', '/generate/improve', [
            'methods'  => 'POST',
            'callback' => [ $this, 'handle_improve' ],
            'permission_callback' => '__return_true',
        ]);
    }

    public function handle_generate( WP_REST_Request $request ) {
        $api_key = get_option( 'social_spark_ai_openai_key' );
        
        if ( empty( $api_key ) ) {
            return new WP_Error( 'missing_api_key', 'OpenAI API key is not configured in settings.', [ 'status' => 500 ] );
        }

        $params = $request->get_json_params();
        
        $campaign_name = sanitize_text_field( $params['campaignName'] ?? '' );
        $product_name = sanitize_text_field( $params['productName'] ?? '' );
        $product_desc = sanitize_textarea_field( $params['productDescription'] ?? '' );
        $target_audience = sanitize_text_field( $params['targetAudience'] ?? '' );
        $primary_benefit = sanitize_text_field( $params['primaryBenefit'] ?? '' );
        $tone = sanitize_text_field( $params['tone'] ?? 'Professional' );
        $platforms = array_map( 'sanitize_text_field', $params['platforms'] ?? [] );

        if ( empty( $campaign_name ) || empty( $product_name ) ) {
            return new WP_Error( 'invalid_params', 'Missing required fields.', [ 'status' => 400 ] );
        }

        $style_guide = "You write highly engaging, deeply personal, long-form social media content for service providers, creators, and affiliate marketers.
CRITICAL RULES FOR OUTPUT QUALITY:
1. LONG-FORM STORYTELLING: Every post's body MUST be a minimum of 3-4 distinct paragraphs (200-300+ words, roughly 20 lines). Absolutely NO short 50-word blurbs.
2. NARRATIVE DRIVEN: Start with a deeply personal hook. Transition into an 'origin story', a frustrating struggle, or a relatable 'slice of life' narrative.
3. BE SPECIFIC & HUMAN: Talk about late nights, specific frustrations, hobbies, or 'aha!' moments. Use contractions, conversational tone, and vivid sensory details. 
4. MARKETING PSYCHOLOGY: Weave the product/service naturally into the climax of the story. Use Brunson-style epiphany bridges.
5. NO GENERIC AI FILLER: Never say 'In today's fast-paced world', or overuse emojis. Write like a passionate, real human sharing a raw story.";

        $system_prompt = $style_guide . "\n\nProduce exactly 3 extremely detailed, long-form posts as JSON: { \"posts\": [ ... ] }, one per day (dayNumber 1-3). Sequence the 3 days to give a premium taste of the full strategy. Each post needs: dayNumber, pillar (TRUST, BRAND, or SELL), hook (first line, scroll-stopping), body (MUST BE 3-4 PARAGRAPHS MINIMUM, deeply personal, heavily narrative-driven, at least 20 lines long), cta, visualIdea (a short text describing an image or video concept to pair with this post), hashtags (max 10). Return ONLY JSON matching this schema:
{
  \"posts\": [
    {
      \"dayNumber\": 1,
      \"pillar\": \"string\",
      \"hook\": \"string\",
      \"body\": \"string\",
      \"cta\": \"string\",
      \"visualIdea\": \"string\",
      \"hashtags\": [\"string\"]
    }
  ]
}";

        $user_prompt = "Campaign: $campaign_name\nProduct: $product_name\nDescription: $product_desc\nAudience: $target_audience\nBenefit: $primary_benefit\nTone: $tone\nPlatforms: " . implode(', ', $platforms);

        $body = [
            'model' => 'gpt-4o',
            'messages' => [
                [ 'role' => 'system', 'content' => $system_prompt ],
                [ 'role' => 'user', 'content' => $user_prompt ]
            ],
            'response_format' => [ 'type' => 'json_object' ],
            'temperature' => 0.7,
        ];

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode( $body ),
            'timeout' => 180,
        ]);

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'openai_error', $response->get_error_message(), [ 'status' => 500 ] );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        
        if ( $code !== 200 ) {
            return new WP_Error( 'openai_error', 'OpenAI API returned an error: ' . $code, [ 'status' => 500 ] );
        }

        $data = json_decode( $body, true );
        $content = json_decode( $data['choices'][0]['message']['content'], true );

        $posts = $content['posts'];
        // DEFENSIVE CHECK: Forcefully restrict to a maximum of 3 posts.
        if ( is_array( $posts ) && count( $posts ) > 3 ) {
            $posts = array_slice( $posts, 0, 3 );
        }

        return rest_ensure_response( [
            'success' => true,
            'posts' => $posts
        ] );
    }

    public function handle_improve( WP_REST_Request $request ) {
        $api_key = get_option( 'social_spark_ai_openai_key' );
        
        if ( empty( $api_key ) ) {
            return new WP_Error( 'missing_api_key', 'OpenAI API key is not configured in settings.', [ 'status' => 500 ] );
        }

        $params = $request->get_json_params();
        $content = sanitize_textarea_field( $params['content'] ?? '' );
        
        if ( empty( $content ) ) {
            return new WP_Error( 'invalid_params', 'Missing content to improve.', [ 'status' => 400 ] );
        }

        $style_guide = "You write basic, short social media content.
CRITICAL RULES FOR OUTPUT QUALITY:
1. VERY SHORT FORM: Every post's body MUST be exactly 1 short paragraph (maximum 30-50 words). Do NOT write long paragraphs.";

        $system_prompt = $style_guide . "\n\nThe user is asking you to improve a social media post. Make it slightly better, but keep it very short (1 paragraph max). Do NOT change the core meaning. Produce exactly one post as JSON with fields: hook, body, visualIdea. Return ONLY JSON matching this schema:
{
  \"hook\": \"string\",
  \"body\": \"string\",
  \"visualIdea\": \"string\"
}";

        $body = [
            'model' => 'gpt-4o',
            'messages' => [
                [ 'role' => 'system', 'content' => $system_prompt ],
                [ 'role' => 'user', 'content' => $content ]
            ],
            'response_format' => [ 'type' => 'json_object' ],
            'temperature' => 0.7,
        ];

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode( $body ),
            'timeout' => 180,
        ]);

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'openai_error', $response->get_error_message(), [ 'status' => 500 ] );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        
        if ( $code !== 200 ) {
            return new WP_Error( 'openai_error', 'OpenAI API returned an error: ' . $code, [ 'status' => 500 ] );
        }

        $data = json_decode( $body, true );
        $improved_content = json_decode( $data['choices'][0]['message']['content'], true );

        return rest_ensure_response( [
            'success' => true,
            'improved' => $improved_content
        ] );
    }
}
