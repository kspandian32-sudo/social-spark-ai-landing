<?php
/**
 * Plugin Name: Social Spark AI (Free Version)
 * Description: AI-powered social media generation directly in WordPress. Limited to basic outputs. Upgrade to Pro for full 30-day Storytelling generation.
 * Version: 1.0.0
 * Author: Pandian AI
 * Text Domain: social-spark-ai
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

define( 'SOCIAL_SPARK_AI_VERSION', '1.0.0' );
define( 'SOCIAL_SPARK_AI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SOCIAL_SPARK_AI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Load plugin classes
require_once SOCIAL_SPARK_AI_PLUGIN_DIR . 'includes/class-settings.php';
require_once SOCIAL_SPARK_AI_PLUGIN_DIR . 'includes/class-api.php';
require_once SOCIAL_SPARK_AI_PLUGIN_DIR . 'includes/class-shortcode.php';

// Initialize the plugin
function social_spark_ai_init() {
    new Social_Spark_AI_Settings();
    new Social_Spark_AI_API();
    new Social_Spark_AI_Shortcode();
}
add_action( 'plugins_loaded', 'social_spark_ai_init' );
