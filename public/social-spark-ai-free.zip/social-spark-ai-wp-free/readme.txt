=== Social Spark AI (Free Version) ===
Contributors: kspandian32
Tags: AI, OpenAI, social media, content generator, chatgpt, marketing automation, automated social media
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

AI-powered social media generation directly in WordPress. Generate content instantly using your own OpenAI API key.

== Description ==

Social Spark AI is a lightweight, natively-integrated WordPress plugin that allows you to generate social media content using the power of OpenAI, right from your WordPress dashboard.

Stop paying expensive monthly SaaS subscriptions! With Social Spark AI, you connect your own OpenAI API key and generate content for pennies. 

### Free Version Features
*   **Native WordPress Integration:** Paste the `[social_spark_ai]` shortcode anywhere to use the tool.
*   **Bring Your Own Key:** Connect your own OpenAI API key for maximum privacy and low costs.
*   **Basic Content Generation:** Generate short, highly-optimized social media posts.

### Unlock the PRO Storytelling Engine
This free version is limited to short, 1-paragraph outputs. Upgrade to **Social Spark AI PRO** to unlock our proprietary 30-Day Storytelling Architecture. The PRO version generates 30 days of long-form, deeply personal, 3-4 paragraph narratives designed to convert readers into buyers using proven Epiphany Bridge marketing psychology.

Upgrade to PRO here: https://digital.pandian-ai.com

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/social-spark-ai` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to **Settings -> Social Spark AI** in your WordPress dashboard.
4. Follow the step-by-step tutorial on the screen to connect your OpenAI API key.
5. Paste the shortcode `[social_spark_ai]` on any page or post!

== Frequently Asked Questions ==

= Do I need an OpenAI account? =
Yes, you must have an OpenAI account with a minimum $5 billing credit balance to use the API. 

= Is my data safe? =
Yes! In the plugin settings, we provide a tutorial on how to configure your OpenAI Data Controls to ensure OpenAI NEVER uses your prompts or data for training.

== Screenshots ==

1. The incredibly intuitive content generation interface.
2. The Settings page with step-by-step API setup tutorials.
