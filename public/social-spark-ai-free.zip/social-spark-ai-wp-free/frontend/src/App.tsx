import React, { useState, useEffect } from "react";
import { Zap, Rocket, Copy } from "lucide-react";
import { Button, Input, Textarea, Select, Label, Card, CardContent } from "./components";

// @ts-ignore
const wpConfig = window.SocialSparkAIConfig || { apiUrl: 'http://localhost:3000/wp-json/social-spark/v1', nonce: '' };

const PLATFORMS = ["LINKEDIN", "TWITTER", "INSTAGRAM", "FACEBOOK", "TIKTOK"];

export default function App() {
  const [results, setResults] = useState<any[] | null>(null);
  
  const [mode, setMode] = useState<"single" | "campaign">("campaign");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [campaignName, setCampaignName] = useState("");
  const [productName, setProductName] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [niche, setNiche] = useState("");
  const [platform, setPlatform] = useState(PLATFORMS[0]);

  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState("Starting generation...");

  useEffect(() => {
    if (!loading) return;
    const duration = mode === "campaign" ? 60000 : 15000;
    const intervalTime = 100;
    const steps = duration / intervalTime;
    let currentStep = 0;
    
    const statuses = ["Analyzing...", "Writing narratives...", "Adding formatting...", "Finalizing..."];
    const interval = setInterval(() => {
      currentStep++;
      const percent = Math.min(99, Math.floor((currentStep / steps) * 100));
      setProgress(percent);
      setLoadingText(statuses[Math.floor((percent / 100) * statuses.length)] || "Finishing up...");
    }, intervalTime);
    
    return () => clearInterval(interval);
  }, [loading, mode]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const payload = {
      campaignName: mode === "campaign" ? campaignName : "Single Post",
      productName,
      productDescription,
      targetAudience: niche,
      primaryBenefit: "Save time and grow",
      tone: "Professional",
      platforms: [platform]
    };

    try {
      const res = await fetch(`${wpConfig.apiUrl}/generate`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "X-WP-Nonce": wpConfig.nonce
        },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.message ?? "Something went wrong.");
        setLoading(false);
        return;
      }
      setProgress(100);
      setResults(json.posts);
      setLoading(false);
    } catch {
      setError("Network error — please check your connection.");
      setLoading(false);
    }
  }

  if (results) {
    return (
      <div className="flex flex-col gap-6 p-4 font-sans text-gray-900 max-w-4xl mx-auto">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Your Generated Content</h2>
          <Button onClick={() => setResults(null)}>Generate New</Button>
        </div>
        <div className="grid gap-6">
          {results.map((post, i) => (
            <PostItem key={i} initialPost={post} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 p-4 font-sans text-gray-900 max-w-2xl mx-auto">
      <div className="rounded-2xl border border-purple-200 bg-purple-50 p-6">
        <h3 className="text-xl font-bold text-purple-900">
          🚀 Social Spark AI Generator
        </h3>
        
        <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <Label>Campaign Name</Label>
            <Input required value={campaignName} onChange={(e) => setCampaignName(e.target.value)} />
          </div>
          <div className="flex flex-col gap-2">
            <Label>Product Name</Label>
            <Input required value={productName} onChange={(e) => setProductName(e.target.value)} />
          </div>
          <div className="flex flex-col gap-2">
            <Label>Product Description</Label>
            <Textarea required value={productDescription} onChange={(e) => setProductDescription(e.target.value)} />
          </div>
          <div className="flex flex-col gap-2">
            <Label>Target Audience / Niche</Label>
            <Input required value={niche} onChange={(e) => setNiche(e.target.value)} />
          </div>
          <div className="flex flex-col gap-2">
            <Label>Platform</Label>
            <Select value={platform} onChange={(e) => setPlatform(e.target.value)}>
              {PLATFORMS.map((p) => <option key={p} value={p}>{p}</option>)}
            </Select>
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}

          {loading ? (
            <div className="flex flex-col items-center justify-center p-6 bg-white rounded-xl border shadow-sm">
              <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden border">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
              </div>
              <p className="mt-4 text-sm font-semibold">{progress}% — {loadingText}</p>
            </div>
          ) : (
            <Button type="submit" size="lg" className="w-full bg-purple-600 hover:bg-purple-700 text-white">
              🚀 Generate Content
            </Button>
          )}
        </form>
      </div>
    </div>
  );
}

function PostItem({ initialPost }: { initialPost: any }) {
  const [currentHook, setCurrentHook] = useState(initialPost.hook || "");
  const [currentBody, setCurrentBody] = useState(initialPost.body || initialPost.content || "");
  const [isImproving, setIsImproving] = useState(false);

  async function improvePost() {
    setIsImproving(true);
    try {
      const res = await fetch(`${wpConfig.apiUrl}/generate/improve`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "X-WP-Nonce": wpConfig.nonce
        },
        body: JSON.stringify({ content: JSON.stringify({ hook: currentHook, body: currentBody }) }),
      });
      const json = await res.json();
      if (json.success && json.improved) {
        setCurrentHook(json.improved.hook);
        setCurrentBody(json.improved.body);
      } else {
        alert("Failed to improve post");
      }
    } catch {
      alert("Network error");
    } finally {
      setIsImproving(false);
    }
  }

  function copyPost() {
    const text = [
      currentHook, 
      "", 
      currentBody, 
      "", 
      initialPost.cta || "", 
      "", 
      (initialPost.hashtags || []).map((h: string) => `#${h}`).join(" "),
      "",
      "---",
      "📸 Visual Idea:",
      initialPost.visualIdea || ""
    ].filter(Boolean).join("\n");
    navigator.clipboard.writeText(text);
    alert("Copied!");
  }

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-center mb-4">
          <span className="font-bold text-gray-500">Day {initialPost.dayNumber || initialPost.day}</span>
          <span className={`px-2 py-1 text-xs font-bold rounded uppercase ${
            initialPost.pillar === 'TRUST' ? 'bg-blue-100 text-blue-800' : 
            initialPost.pillar === 'BRAND' ? 'bg-pink-100 text-pink-800' : 
            'bg-green-100 text-green-800'
          }`}>
            {initialPost.pillar || initialPost.theme || "POST"}
          </span>
        </div>
        
        <p className="font-semibold mb-2">{currentHook}</p>
        <div className="whitespace-pre-wrap text-sm text-gray-800 mb-4">{currentBody}</div>
        <p className="text-sm font-medium mb-4">{initialPost.cta}</p>

        {initialPost.visualIdea && (
          <div className="mt-2 mb-4 rounded-lg bg-blue-50/50 p-3 border border-blue-100">
            <p className="text-xs font-semibold text-blue-700 mb-1">📸 Visual Idea</p>
            <p className="text-xs text-blue-900 leading-relaxed">{initialPost.visualIdea}</p>
          </div>
        )}

        {(initialPost.hashtags && initialPost.hashtags.length > 0) && (
          <p className="text-xs text-purple-600 font-medium mb-4">
            {initialPost.hashtags.map((h: string) => `#${h}`).join(" ")}
          </p>
        )}

        <div className="mt-4 flex gap-2">
          <Button size="sm" className="flex-1" onClick={copyPost}>
            <Copy className="w-4 h-4 mr-2" /> Copy Full Post
          </Button>
          <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700 text-white" disabled={isImproving} onClick={improvePost}>
            {isImproving ? "✨ Improving..." : "✨ Improve this Post"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
